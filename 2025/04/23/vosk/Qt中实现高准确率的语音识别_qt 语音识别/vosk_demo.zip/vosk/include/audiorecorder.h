﻿#include <QAudioInput>
#include <QFile>
#include <QTimer>
#include <QDebug>
#include <vosk_api.h>
#include <iostream>

#include <QCoreApplication>

// 音频录制类
class AudioRecorder : public QObject {
    Q_OBJECT

public:
    AudioRecorder(QObject *parent = nullptr) : QObject(parent), audioFile("audio.temp") {
        // 设置音频格式：16kHz、单声道、16位深度
        QAudioFormat format;
        format.setSampleRate(16000);
        format.setChannelCount(1);
        format.setSampleSize(16);
        format.setCodec("audio/pcm");
        format.setByteOrder(QAudioFormat::LittleEndian);
        format.setSampleType(QAudioFormat::SignedInt);

        // 初始化音频输入
        audioInput = new QAudioInput(format, this);

        // 打开文件
        if (!audioFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            qWarning() << "无法打开文件进行录音";
            return;
        }
    }

    void startRecording(int durationMs) {
        audioInput->start(&audioFile);
        qDebug() << "start......";

        // 设置录音时间，完成后停止录音
        // 在这里修改，可将录音指定时间，改为指定事件触发再执行&AudioRecorder::stopRecording
        QTimer::singleShot(durationMs, this, &AudioRecorder::stopRecording);
    }

signals:
    void recordingFinished();

public slots:
    void stopRecording() {
        audioInput->stop();
        audioFile.close();
        qDebug() << "over";

        // 触发录音完成信号
        emit recordingFinished();
    }

private:
    QAudioInput *audioInput;
    QFile audioFile;
};

// 语音识别类
class SpeechRecognizer : public QObject {
    Q_OBJECT

public:
    SpeechRecognizer(const QString &modelPath, QObject *parent = nullptr) : QObject(parent) {
        // 加载模型
        model = vosk_model_new(modelPath.toStdString().c_str());
        if (model == nullptr) {
            qWarning() << "无法加载模型";
        }
    }

    ~SpeechRecognizer() {
        vosk_model_free(model);
    }

    void recognize() {
        // 创建识别器
        VoskRecognizer *recognizer = vosk_recognizer_new(model, 16000.0);

        // 打开录音文件
        QString audioFilePath = QCoreApplication::instance()->applicationDirPath() + "/audio.temp";
        FILE *audioFile = fopen(audioFilePath.toStdString().c_str(), "rb");
        if (audioFile == nullptr) {
            qWarning() << "无法打开音频文件";
            vosk_recognizer_free(recognizer);
            return;
        }

        // 读取音频并识别
        char buffer[4096];
        int bytesRead;
        while ((bytesRead = fread(buffer, 1, sizeof(buffer), audioFile)) > 0) {
            if (vosk_recognizer_accept_waveform(recognizer, buffer, bytesRead)) {
                //每句识别结果
                QString result = QString::fromUtf8(vosk_recognizer_result(recognizer));
                qDebug() << "result:" << result;
            } else {
                //过程部分识别
                QString partial = QString::fromUtf8(vosk_recognizer_partial_result(recognizer));
                qDebug() << "part result:" << partial;
            }
        }

        // 获取最终识别结果，测试感觉不好用
        //QString finalResult = QString::fromUtf8(vosk_recognizer_final_result(recognizer));
        //qDebug() << "final result:" << finalResult;

        // 释放资源
        fclose(audioFile);
        vosk_recognizer_free(recognizer);
    }

private:
    VoskModel *model;
};
