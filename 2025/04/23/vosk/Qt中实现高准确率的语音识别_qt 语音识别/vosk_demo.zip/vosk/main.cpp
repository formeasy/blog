﻿
#include "include/audiorecorder.h"
#include <QCoreApplication>
#include <QDebug>
#include <QTextCodec>
#include <QDataStream>


int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    // 设置模型路径
    QString modelPath = QCoreApplication::instance()->applicationDirPath() + "/vosk-model";
    SpeechRecognizer recognizer(modelPath);

    // 创建录音对象
    AudioRecorder recorder;

    // 录音完成后进行识别
    QObject::connect(&recorder, &AudioRecorder::recordingFinished, [&recognizer]() {
        recognizer.recognize();
    });

    // 开始录音
    recorder.startRecording(5000);



    return app.exec();
}
